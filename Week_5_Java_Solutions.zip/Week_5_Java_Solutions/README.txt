WEEK 5 - JAVA SOLUTIONS

Session 1
Task 1 - Maximum Subarray
Task 2 - Birthday Bar / Subarray Division

Session 2
Task 3 - The Maximum Subarray
Task 4 - Maximum Sum Circular Subarray

Session 3
Task 5 - String to Integer (atoi)
Task 6 - Alternating Characters

Session 4
Task 7 - Longest Substring Without Repeating Characters
Task 8 - Find and Replace Pattern

Session 5
Task 9 - String Matching in an Array
Task 10 - Naive Pattern Searching

NOTES
- Java solutions only.
- No Scanner input code.
- No BufferedReader input code.
- No main method.
- No sample input/output code.
- Code is formatted clearly line by line.
- LeetCode files use class Solution.
- HackerRank files use class Result.
- GeeksforGeeks Task 10 uses class GFG and search() method.
